from django.urls import path
from .views import adicionar_ao_carrinho, exibir_carrinho

urlpatterns = [
    path('adicionar/<int:produto_id>/', adicionar_ao_carrinho, name='adicionar_ao_carrinho'),
    path('', exibir_carrinho, name='exibir_carrinho'),  # '/' para exibir o carrinho
]